import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Landpageuser extends Component {

	render() {
		return (
			<div id="content" className="col-md-12 d-flex justify-content-center text-center align-items-center">
				<div className="col-md-4 d-flex flex-column">
					<h2>Pilih Fitur :</h2>
					<Link to="/uploadfile"><button className="btn btn-info" style={{minWidth: '100px'}}>Registrasi Sertifikat</button></Link>
					<pre></pre>
					<Link to="/validasiqr"><button className="btn btn-success" style={{minWidth: '100px'}}>Validasi Sertifikat</button></Link>
					<pre></pre>
					<Link to="/dataperalihan"><button className="btn btn-secondary" style={{minWidth: '100px'}}>Data Peralihan Hak</button></Link>
				</div>
			</div>
		);
	}
}

export default Landpageuser;