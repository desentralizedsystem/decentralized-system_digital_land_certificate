import React, { Component } from 'react';
var QRCode = require('qrcode.react');

export class Datasertifikat extends Component {
	render() {
		return (
			<div className="col-md-13">
				<h3>Data Sertifikat Digital</h3>
				<hr className="my-4"/>
				<table className="table table-bordered">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col">Nomor</th>
							<th scope="col">NIK</th>
							<th scope="col">Alamat</th>
							<th scope="col">Kota</th>
							<th scope="col">Provinsi</th>
							<th scope="col">Panjang</th>
							<th scope="col">Lebar</th>
							<th scope="col">QRCode</th>
						</tr>
					</thead>
					<tbody>
						{this.props.sertifikats.filter(p => p.owner === this.props.account).length > 0
							? this.props.sertifikats
								.filter(p => p.owner)
								.map((sertifikat, key) => {
								return (
									<tr key={key}>
										<th scope="row">{key+1}</th>
										<td>{sertifikat.no_sertifikat}</td>
										<td>{sertifikat.nik}</td>
										<td>{sertifikat.alamat}</td>
										<td>{sertifikat.kota}</td>
										<td>{sertifikat.prov}</td>
										<td>{sertifikat.panjang}</td>
										<td>{sertifikat.lebar}</td>
										<td><QRCode value={sertifikat.hash_sertifikat}/>{sertifikat.hash_sertifikat}</td>
									</tr>
								)
								})
							: <tr><td colSpan="9" className="text-center">Data sertifikat tidak ditemukan.</td></tr>
						}
					</tbody>
				</table>
			</div>
		)
	}
}

export default Datasertifikat