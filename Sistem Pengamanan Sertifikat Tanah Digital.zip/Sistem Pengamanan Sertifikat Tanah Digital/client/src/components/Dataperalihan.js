import React, { Component } from 'react';
var QRCode = require('qrcode.react');

export class Dataperalihan extends Component {
	constructor(props) {
		super(props)
		this.state = {
			no_sertifikat:'',
			value: '', 
			watching: false
		}
		this.onFind = this.onFind.bind(this)
	}
	
	onFind (value) {
		this.setState({ value, watching: false })
	}
	printpage(){
		window.print()
	}
	   	
	
	render() {
		return (				
			<div className="col-md-12">
				<div className="col-md-9">
					<div>
						<h3>Data Peralihan Hak Kepemilikan Sertifikat Tanah</h3>
					</div>					
					<form 
						onSubmit={(event) => {
							event.preventDefault()
							const no_sertifikat = this.no_sertifikat.value
							this.setState({no_sertifikat:no_sertifikat})
						}}>
						<div className="form-group mr-sm-2">
							<label htmlFor="no_sertifikat">Nomor Sertifikat</label>
							<input
							id="no_sertifikat"
							type="text"
							ref={(input) => { this.no_sertifikat = input }}
							className="form-control"
							required
							/>
							
						</div>
						<button type="submit" className="btn btn-info">Check</button>
					</form>
				</div>
				
				<hr className="my-7"/>
						{(this.props.sertifikats.filter(p => p.owner === this.props.account).length > 0)
							? this.props.sertifikats
								.filter(p => p.no_sertifikat === this.state.no_sertifikat)
								.map((sertifikat, key) => {
								return (
								
								<table className="table table-bordered">
									<thead>
										<tr>
											<th scope="col"></th>
											<th scope="col">Nomor</th>
											<th scope="col">NIK Pemilik</th>
											<th scope="col">QRCode</th>							
											<th scope="col">Tanggal Terbit</th>
										</tr>
									</thead>
									<tbody>									
									<tr key={key}>
										<th scope="row">{key+1}</th>
										<td>{sertifikat.no_sertifikat}</td>
										<td>{sertifikat.nik}</td>
										<td><QRCode value={sertifikat.hash_sertifikat}/></td>
										<td>{sertifikat.tanggal_terbit}</td>																			
									</tr>
									</tbody>			
								</table>
								)
								})
							: <tr><td colSpan="6" className="text-center">Data sertifikat tidak ditemukan.</td></tr>	
						}							
			</div>
		)
	}
	
}


export default Dataperalihan

