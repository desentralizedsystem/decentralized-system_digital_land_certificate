import React, { Component } from 'react'

export class Datapemohon extends Component {

	render() {
		return (
		<div className="col-md-20"> 
			<iframe title="data_pengajuan" 
			src="https://docs.google.com/spreadsheets/d/e/2PACX-1vQw3FIEfHAYk8cfOqKmFgqmlV5YV3ctUEms5U800Q55OO8260ghaHxVUh-k-zyvbB0PV7H-dMRSmvd8/pubhtml?gid=1075256657&amp;single=true&amp;widget=true&amp;headers=false"
			width="1300" height="2000" frameBorder="0" marginHeight="0" marginWidth="0"></iframe>
        </div> 

		)
	}
}

export default Datapemohon