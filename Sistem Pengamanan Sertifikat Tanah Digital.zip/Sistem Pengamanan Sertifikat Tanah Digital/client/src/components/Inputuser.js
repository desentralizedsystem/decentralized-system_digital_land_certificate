import React, { Component } from 'react'

export class Inputuser extends Component {
	render() {
		return (
			<div className="col-md-12">
				<div className="col-md-4">
					<h1>Input User</h1>
					<form 
						onSubmit={(event) => {
							event.preventDefault()
							const name = this.userName.value
							const nik = this.nik.value
							this.props.createUser(name, nik)
						}}>
						<div className="form-group mr-sm-2">
							<label htmlFor="userName">Nama</label>
							<input
							id="userName"
							type="text"
							ref={(input) => { this.userName = input }}
							className="form-control"
							placeholder=""
							required />
						</div>
						<div className="form-group mr-sm-2">
							<label htmlFor="nik">NIK</label>
							<input
							id="nik"
							type="text"
							ref={(input) => { this.nik = input }}
							className="form-control"
							placeholder=""
							required />
						</div>
						<button type="submit" className="btn btn-info">Submit</button>
					</form>
				</div>
				<hr className="my-4"/>
				<h5>User Terdaftar</h5>
				<table className="table table-bordered">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col">Nama</th>
							<th scope="col">NIK</th>
						</tr>
					</thead>
					<tbody>
						{this.props.users.filter(p => p.owner === this.props.account).length > 0
							? this.props.users
								.filter(p => p.owner === this.props.account)
								.map((user, key) => {
								return (
									<tr key={key}>
										<th scope="row">{key+1}</th>
										<td>{user.name}</td>
										<td>{user.nik}</td>
									</tr>
								)
								})
							: <tr><td colSpan="3" className="text-center">Data tidak tersedia.</td></tr>
						}
					</tbody>
				</table>
			</div>
		)
	}
}

export default Inputuser