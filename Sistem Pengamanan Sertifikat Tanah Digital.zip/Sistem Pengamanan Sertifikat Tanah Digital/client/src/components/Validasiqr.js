import React, { Component } from 'react';
import QRScan from 'qrscan';
var QRCode = require('qrcode.react');

export class Validasiqr extends Component {
	constructor(props) {
		super(props)
		this.state = {
			hash_sertifikat:'',
			value: '', 
			watching: false
		}
		this.onFind = this.onFind.bind(this)
	}
	
	onFind (value) {
		this.setState({ value, watching: false })
	}
	printpage(){
		window.print()
	}
	
	
	render() {
		return (				
			<div className="col-md-12">
				<div className="col-md-9">
					<div>
						<h3>Klik tombol <button onClick={() => this.setState({ watching: true })}>Scan</button> untuk memulai pemindaian kode QR.</h3>
						{this.state.watching
						? (
							<QRScan onFind={this.onFind} />
						)
						: (
							<div>
							</div>
						)
						}
					</div>					
					<p></p>
					<form 
						onSubmit={(event) => {
							event.preventDefault()
							const hash_sertifikat = this.hash_sertifikat.value
							this.setState({hash_sertifikat:hash_sertifikat})
						}}>
						<div className="form-group mr-sm-2">
							<label htmlFor="hash_sertifikat">Hash Sertifikat</label>
							<input
							id="hash_sertifikat"
							type="text"
							ref={(input) => { this.hash_sertifikat = input }}
							value = {this.state.value}
							className="form-control"
							disabled/>	
						</div>
						<button type="submit" className="btn btn-info">Check</button>
					</form>
					
				</div>
				
				<hr className="my-7"/>
						{(this.props.sertifikats.filter(p => p.owner === this.props.account).length > 0)
							? this.props.sertifikats
								.filter(p => p.hash_sertifikat === this.state.hash_sertifikat)
								.map((sertifikat, key) => {
								return (
								
								<table className="table table-bordered">
									<thead>
									<tr><td colSpan="7">
										<img alt ="logogaruda" src={require('./img/garuda.png')} width="50" height="50"/>
										<img alt="logobpn" src={require('./img/Logo_BPN.png')} width="50" height="50"/>
										<h5>Badan Pertanahan Nasional Republik Indonesia</h5>
									</td></tr>
										<tr>
											<th scope="col"></th>
											<th scope="col">Nomor</th>
											<th scope="col">Alamat</th>
											<th scope="col">Kota</th>
											<th scope="col">Provinsi</th>							
											<th scope="col">QRCode</th>
											<th scope="col">Status</th>
										</tr>
									</thead>
									<tbody>									
									<tr key={key}>
										<th scope="row">{key+1}</th>
										<td>{sertifikat.no_sertifikat}</td>
										<td>{sertifikat.alamat}</td>
										<td>{sertifikat.kota}</td>
										<td>{sertifikat.prov}</td>										
										<td><QRCode value={sertifikat.hash_sertifikat}/></td>
										<td><button type="button" className="btn btn-success" onClick={this.printpage}>Valid</button></td>																			
									</tr>
									</tbody>			
								</table>
								)
								})
							: <tr><td colSpan="6" className="text-center">Data sertifikat tidak ditemukan.</td></tr>	
						}							
			</div>
		)
	}	
}
export default Validasiqr

