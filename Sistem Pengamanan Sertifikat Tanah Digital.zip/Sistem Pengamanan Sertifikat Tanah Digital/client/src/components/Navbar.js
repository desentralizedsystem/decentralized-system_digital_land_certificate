import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Navbar extends Component {

	render() {
		return (
			<nav className="navbar navbar-expand-lg navbar-light shadow">
				<Link
					className="navbar-brand"
					to="/"
					rel="noopener noreferrer"
				>
					<img src={require('./img/Logo_BPN.png')} width="30" height="30" className="d-inline-block align-top" alt="logobrand" />
					BPN
				</Link>
				<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span className="navbar-toggler-icon"></span>
				</button>
				<div className="collapse navbar-collapse" id="navbarSupportedContent">
					<ul className="navbar-nav mr-auto">
						<li className={this.props.active === 'input_user' ? 'nav-item active' : 'nav-item'}>
							<Link className="nav-link" to="/input_user">Input User</Link>
						</li>
						<li className={this.props.active === 'input_sertif' ? 'nav-item active' : 'nav-item'}>
							<Link className="nav-link" to="/input_sertif">Input Sertifikat</Link>
						</li>
						<li className={this.props.active === 'datasertifikat' ? 'nav-item active' : 'nav-item'}>
							<Link className="nav-link" to="/datasertifikat">Data Sertifikat</Link>
						</li>
						<li className={this.props.active === 'validasiqr' ? 'nav-item active' : 'nav-item'}>
							<Link className="nav-link" to="/validasiqr">Validasi QR</Link>
						</li>
						<li className={this.props.active === 'dataperalihan' ? 'nav-item active' : 'nav-item'}>
							<Link className="nav-link" to="/dataperalihan">Data Peralihan Hak</Link>
						</li>
						<li className={this.props.active === 'datapemohon' ? 'nav-item active' : 'nav-item'}>
							<Link className="nav-link" to="/datapemohon">Data Pemohon</Link>
						</li>
						
					</ul>
					<div className="d-flex flex-column">
						<small className="nav-link text-dark p-0"><span id="account">Account: <b>{this.props.account}</b></span></small>
						<small className="nav-link text-dark p-0"><span id="account">Balance: <b>{this.props.balance} ETH</b></span></small>
					</div>
				</div>
			</nav>
		);
	}
}

export default Navbar;