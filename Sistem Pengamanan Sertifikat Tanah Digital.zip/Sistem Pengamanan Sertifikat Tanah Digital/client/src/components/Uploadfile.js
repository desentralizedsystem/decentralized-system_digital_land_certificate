import React, { Component } from 'react'

export class Uploadfile extends Component {

	render() {
		return (
		<div> 
			
            <div>
				<h2>Dokumen Pendukung :</h2>
				<div className="col-md-7">
				Silahkan isi data berikut untuk melakukan pengajuan pendaftaran sertifikat tanah digital. File pendukung diperlukan untuk validasi data anda. *Silahkan terlebih dahulu mengupload file anda ke dalam drive kemudian salin link ke form yang disediakan.
				</div>
				<ul>
					<li>KTP</li>
					<li>Kartu Keluarga</li>
					<li>Akta Jual Beli</li>
					<li>Bukti Bayar BPHTB</li>
					<li>Bukti Bayar PNBP</li>
				</ul>
				<iframe title="unggah_dokumen" src="https://docs.google.com/forms/d/e/1FAIpQLSfRjnwPabzlom7IlQMGbrRxLtuCzqeQUyebUxzZlT_BdWaRzA/viewform?embedded=true" 
				width="670" height="1000" frameBorder="0" marginHeight="0" marginWidth="0"></iframe>
            </div>
        </div> 

		)
	}
}

export default Uploadfile