import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Main extends Component {
	inputpassword(){
		let passwd = "";
		passwd = window.prompt("Silahkan masukkan password Admin :","");
		while (passwd !== "admin999"){
			passwd = window.prompt("Password yang dimasukkan salah, silahkan masukkan kembali","");
		}
	}
	render() {
		return (
			<div id="content" className="col-md-12 d-flex justify-content-center text-center align-items-center">
				<div className="col-md-4 d-flex flex-column">
					<h2>User Sebagai:</h2>
					<Link to="/input_user"><button className="btn btn-primary" style={{minWidth: '200px'}} onClick={this.inputpassword}>Admin BPN</button></Link>
					<span>atau</span>
					<Link to="/landpageuser"><button className="btn btn-warning" style={{minWidth: '200px'}}>Masyarakat</button></Link>
				</div>
			</div>
		);
	}
}

export default Main;