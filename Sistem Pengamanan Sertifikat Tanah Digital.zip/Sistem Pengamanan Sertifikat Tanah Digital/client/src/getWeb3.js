import Web3 from "web3";

const getWeb3 = () =>
  new Promise((resolve, reject) => {
    // Tunggu penyelesaian loading untuk menghindari race condition dengan waktu injection web3.
    window.addEventListener("load", async () => {
      if (window.ethereum) {
        const web3 = new Web3(window.ethereum);
        try {
          // Minta akses akun jika diperlukan
          await window.ethereum.enable();
          // Akun sekarang terbuka
          resolve(web3);
        } catch (error) {
          reject(error);
        }
      }
      else if (window.web3) {
        // Gunakan penyedia Mist atau MetaMask.
        const web3 = window.web3;
        console.log("Injected web3 detected.");
        resolve(web3);
      }
      //Kembali ke localhost, gunakan port console dev secara default
      else {
        const provider = new Web3.providers.HttpProvider(
          "http://127.0.0.1:8545"
        );
        const web3 = new Web3(provider);
        console.log("No web3 instance injected, using Local web3.");
        resolve(web3);
      }
    });
  });

export default getWeb3;
