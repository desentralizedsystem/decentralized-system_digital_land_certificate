const path = require("path");
module.exports = {
    contracts_build_directory: path.join(__dirname, "client/src/contracts"),
    networks: {
        ganache: {
            host: "127.0.0.1",
            port: 7545,
            network_id: "*",
			//gas: 8500000, // Gas sent with each transaction (default: ~6700000) 
			//gasPrice: 20000000000 // 20 gwei (in wei) (default: 100 gwei)
        }
    }
};
